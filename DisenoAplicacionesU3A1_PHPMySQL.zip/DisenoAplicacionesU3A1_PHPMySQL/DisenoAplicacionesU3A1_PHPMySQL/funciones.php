<?php

    function conexion($disenoaplicaciones, $usuario, $password){
        try{
            $conexion = new PDO("mysql:host=localhost;dbname=$disenoaplicaciones", $usuario, $password);
            return $conexion; 
        }catch (PDOException $e){
            return false;
        }
    }

?>