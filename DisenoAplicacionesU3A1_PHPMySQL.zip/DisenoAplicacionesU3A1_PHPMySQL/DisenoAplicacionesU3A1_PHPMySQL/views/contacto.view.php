<?php require 'views/header.php';?>              
    <div class="principal"> 
        <h1 class="titulo_principal"> Contacto </h1>     
    </div>
    <body>        
        <div class="wrap">
            <form class="formulario" method="post" enctype="multipart/form-data">
                <label for="nombre">Ingresa tu nombre</label>
                <input type="text" id="nombre" name="nombre">        
                
                <label for="domicilio">Domicilio</label>
                <input type="text" id="domicilio" name="domicilio">

                <label for="telefono">Telefono</label>
                <input type="text" id="telefono" name="telefono">

                <label for="correo">Correo</label>
                <input type="text" id="correo" name="correo">

                <label for="comentario">Comentario</label>
                <input type="text" id="comentario" name="comentario">

                <input type="submit" name="submit" class="boton boton-primary" value="Enviar datos">
            </form>
        </div>
    </body> 
<?php require 'views/footer.php'?>