<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>BIENVENIDO</title>  
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">       
        <link rel="stylesheet" href="css/estilos.css">                 
    </head>
   <body>
        <img class="banner" src="imagenes/bannerDiseno.jpg">
        <header>         
            <img src="imagenes/logo.jpg"><br><br><br>
            <div class="caja">              
                <nav>                                                         
                    <li><a href="http://localhost/DisenoAplicacionesU3A1_PHPMySQL/index.php" >Home</a></li>
                    <li><a href="http://localhost/DisenoAplicacionesU3A1_PHPMySQL/contacto.php">Contacto</a></li>                 
                </nav> 
            </div>             
        </header> 