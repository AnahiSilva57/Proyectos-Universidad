<?php require 'header.php';?> 
    <div class="principal"> 
        <h1 class="titulo_principal"> BIENVENIDO </h1>     
    </div>              
    <section class="principal"> 
        <h2 class="titulo_principal"> Sitio test de Anahi</h2>
        <p><strong><br>
        <br>Este sitio es para practicar la conexion a MySQL/phpmyadmin y generar registros en la pagina de contacto
        <br><br>Por favor da clic en el boton "CONTACTO" para intentar subir info a la BD
        </strong></p><br>   
    </section>  
    <section class="diferenciales">        
            <center><img src="imagenes/homeDineno.jpg" class="imagen_diferenciales"></center>                 
    </section>
    <?php require 'footer.php'?>