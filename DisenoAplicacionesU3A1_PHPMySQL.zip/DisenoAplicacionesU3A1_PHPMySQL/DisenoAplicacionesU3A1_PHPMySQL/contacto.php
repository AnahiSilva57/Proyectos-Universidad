<?php
    require 'funciones.php';
    $conexion = conexion('disenoaplicaciones','root','');

    if (!$conexion){        
        die();
    }
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){       

            $statement =  $conexion->prepare('
                INSERT INTO clientes (nombre,domicilio,telefono,correo,comentario) 
                VALUES (:nombre, :domicilio, :telefono, :correo, :comentario)
            ');
            $statement->execute(array(
                ':nombre' => $_POST['nombre'], 
                ':domicilio' => $_POST['domicilio'], 
                ':telefono'  => $_POST['telefono'],
                ':correo'  => $_POST['correo'],
                ':comentario'  => $_POST['comentario'],
            ));           
    }
    require 'views/contacto.view.php';
?>